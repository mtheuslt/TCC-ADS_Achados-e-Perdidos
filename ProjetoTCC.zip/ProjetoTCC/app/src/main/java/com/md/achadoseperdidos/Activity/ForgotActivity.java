package com.md.achadoseperdidos.Activity;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.md.achadoseperdidos.R;
import com.muddzdev.styleabletoast.StyleableToast;

public class ForgotActivity extends AppCompatActivity {

    EditText userEmail;
    Button userPass;

    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot);

        userEmail = findViewById(R.id.et_email_address);
        userPass = findViewById(R.id.btn_recovery);

        firebaseAuth = FirebaseAuth.getInstance();

        userPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = userEmail.getText().toString();

                if (email.equals("")) {
                    StyleableToast.makeText(ForgotActivity.this, "O Campo e-mail deve estar preenchido! ", Toast.LENGTH_LONG, R.style.advertenciaToast).show();
                } else {
                    firebaseAuth.sendPasswordResetEmail(userEmail.getText().toString())
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Intent intent = new Intent(ForgotActivity.this, LoginActivity.class);
                                        startActivity(intent);
                                        StyleableToast.makeText(ForgotActivity.this, "Redefinição de senha foi mandada pro seu e-mail! ", Toast.LENGTH_LONG, R.style.sucessoToast).show();
                                    } else {
                                        StyleableToast.makeText(ForgotActivity.this, task.getException().getMessage(), Toast.LENGTH_LONG, R.style.erroToast).show();
                                    }
                                }
                            });
                }

            }
        });

    }
    public void btnVoltar(View view) {
        super.onBackPressed();
    }
}
