package com.md.achadoseperdidos.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.md.achadoseperdidos.Activity.PostDetailActivity;
import com.md.achadoseperdidos.Models.Post;
import com.md.achadoseperdidos.R;
import com.muddzdev.styleabletoast.StyleableToast;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.MyViewHolder> {

    private Context mContext;
    private List<Post> mData;
    private String currentUserId;

    FirebaseAuth mAuth;

    public PostAdapter(Context mContext, List<Post> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    /* Within the RecyclerView.Adapter class */

    // Clean all elements of the recycler
    public void clear() {
        mData.clear();
        notifyDataSetChanged();
    }

    // Add a list of items -- change to type used
    public void addAll(List<Post> list) {
        mData.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View row = LayoutInflater.from(mContext).inflate(R.layout.row_post_item,parent,false);
        return new MyViewHolder(row);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {

        holder.tvTitle.setText(mData.get(position).getTitle());
        holder.tvFoundOrLost.setText(mData.get(position).getCategory());
        holder.tvDesc.setText(mData.get(position).getDescription());
        Glide.with(mContext).load(mData.get(position).getPicture()).into(holder.imgPost);
        Glide.with(mContext).load(mData.get(position).getUserPhoto()).into(holder.imgPostProfile);

        mAuth = FirebaseAuth.getInstance();
        currentUserId = mAuth.getCurrentUser().getUid();

        if(currentUserId.equals(mData.get(position).getUserId())){
            holder.txtOptionDigit.setVisibility(View.VISIBLE);
        } else {
            holder.txtOptionDigit.setVisibility(View.GONE);
            holder.txtOptionDigit.setVisibility(View.INVISIBLE);
        }

        holder.txtOptionDigit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PopupMenu popupMenu = new PopupMenu(mContext, holder.txtOptionDigit);
                popupMenu.inflate(R.menu.option_menu);
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.menu_item_complete:
                                DatabaseReference ref2 = FirebaseDatabase.getInstance().getReference();
                                Query queryComplete = ref2.child("Posts").orderByChild("postKey").equalTo(mData.get(position).getPostKey());

                                queryComplete.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        for (DataSnapshot completeSnapshot: dataSnapshot.getChildren()) {
                                            completeSnapshot.getRef().child("category").setValue("Finalizado");
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });


                                //Toast.makeText(mContext, "Objeto foi devolvido com sucesso!", Toast.LENGTH_SHORT).show();
                                StyleableToast.makeText(mContext, "Finalizado com sucesso!", Toast.LENGTH_LONG, R.style.sucessoToast).show();
                                break;
                            case R.id.menu_item_editar:

                                /*holder.fab.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        popAddPost.show();
                                    }
                                });*/

                                Toast.makeText(mContext, "Editar", Toast.LENGTH_SHORT).show();
                                break;
                            case R.id.menu_item_delete:

                                //Deletar UM Post feito pelo usuário
                                DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                                Query queryDelete = ref.child("Posts").orderByChild("postKey").equalTo(mData.get(position).getPostKey());

                                queryDelete.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        for (DataSnapshot deleteSnapshot: dataSnapshot.getChildren()) {
                                            deleteSnapshot.getRef().removeValue();
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });

                                StyleableToast.makeText(mContext, "Deletado com sucesso!", Toast.LENGTH_LONG, R.style.sucessoToast).show();
                                break;
                             default:
                                 break;
                        }
                        return  false;
                    }
                });
                popupMenu.show();
            }
        });

    }


    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvTitle;
        TextView tvFoundOrLost;
        TextView tvDesc;
        ImageView imgPost;
        TextView txtOptionDigit;
        CircleImageView imgPostProfile;
        FloatingActionButton fab;
        View postView;
        SwipeRefreshLayout swipeContainer;
        //String currentUserId;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTitle = itemView.findViewById(R.id.row_post_title);
            tvFoundOrLost = itemView.findViewById(R.id.row_post_category);
            tvDesc = itemView.findViewById(R.id.blog_desc);
            imgPost = itemView.findViewById(R.id.row_post_img);
            imgPostProfile = itemView.findViewById(R.id.row_post_profile_img);
            txtOptionDigit = itemView.findViewById(R.id.txtOptionDigit);
            fab = itemView.findViewById(R.id.fab);
            postView = itemView.findViewById(R.id.main_blog_post);
            swipeContainer = itemView.findViewById(R.id.swipeContainer);

            // Quando clicar no Post irá para a tela de detalhes
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent postDetailActivity = new Intent(mContext, PostDetailActivity.class);
                    int position = getAdapterPosition();

                    postDetailActivity.putExtra("title", mData.get(position).getTitle());
                    postDetailActivity.putExtra("postImage", mData.get(position).getPicture());
                    postDetailActivity.putExtra("description", mData.get(position).getDescription());
                    postDetailActivity.putExtra("contact", mData.get(position).getContact());
                    postDetailActivity.putExtra("email", mData.get(position).getEmail());
                    postDetailActivity.putExtra("postKey",mData.get(position).getPostKey());
                    postDetailActivity.putExtra("userPhoto",mData.get(position).getUserPhoto());
                    postDetailActivity.putExtra("userName",mData.get(position).getUserName());

                    long timestamp  = (long) mData.get(position).getTimeStamp();
                    postDetailActivity.putExtra("postDate",timestamp) ;
                    mContext.startActivity(postDetailActivity);
                }
            });
        }

    }
}
