package com.md.achadoseperdidos.Activity;

import android.Manifest;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.view.Gravity;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.md.achadoseperdidos.Fragments.FinishFragment;
import com.md.achadoseperdidos.Fragments.FoundFragment;
import com.md.achadoseperdidos.Fragments.HomeFragment;
import com.md.achadoseperdidos.Fragments.LostFragment;
import com.md.achadoseperdidos.Fragments.ProfileFragment;
import com.md.achadoseperdidos.Utils.MaskEditUtil;
import com.md.achadoseperdidos.Models.Post;
import com.md.achadoseperdidos.R;
import com.muddzdev.styleabletoast.StyleableToast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class Home extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private static final int PReqCode = 2;
    private static final int REQUESCODE = 2;
    FirebaseAuth mAuth;
    FirebaseUser currentUser;
    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference mRef;
    Dialog popAddPost;
    ImageView popupPostImag, popupAddBtn;
    CircleImageView popupUserImage;
    TextView popupTitle, popupDescription, popupContact;
    EditText popupSearchMap;
    Spinner popupSpinner;
    ProgressBar popupClickProgress;
    private static Uri pickedImgUri;


    @SuppressWarnings("FieldCanBeLocal")
    // NavigationView
    private BottomNavigationView mainBottomNav;
    private HomeFragment homeFragment;
    private FoundFragment foundFragment;
    private LostFragment lostFragment;
    private ProfileFragment profileFragment;
    private FinishFragment finishFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // ini
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mRef = mFirebaseDatabase.getReference("Posts");

        // ini popup
        iniPopup();
        setupPopupImageClick();

        //Nav Bar (Home, Found and Lost Buttons Main)
        mainBottomNav = findViewById(R.id.mainBottomNav);

        // FRAGMENTS
        homeFragment = new HomeFragment();
        foundFragment = new FoundFragment();
        lostFragment = new LostFragment();
        profileFragment = new ProfileFragment();
        finishFragment = new FinishFragment();

        mainBottomNav.setSelectedItemId(R.id.bottom_action_home);

        mainBottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.bottom_action_home:
                        getSupportActionBar().setTitle("Início");
                        getSupportFragmentManager().beginTransaction().setTransition( FragmentTransaction.TRANSIT_FRAGMENT_OPEN ).
                                replace(R.id.container, homeFragment).addToBackStack("Home").commit();
                        return true;

                    case R.id.bottom_action_found:
                        getSupportActionBar().setTitle("Achado");
                        getSupportFragmentManager().beginTransaction().setTransition( FragmentTransaction.TRANSIT_FRAGMENT_OPEN ).
                                replace(R.id.container, foundFragment).addToBackStack("Achado").commit();
                        return true;

                    case R.id.bottom_action_lost:
                        getSupportActionBar().setTitle("Perdido");
                        getSupportFragmentManager().beginTransaction().setTransition( FragmentTransaction.TRANSIT_FRAGMENT_OPEN ).
                                replace(R.id.container, lostFragment).addToBackStack("Perdido").commit();
                        return true;

                    case R.id.bottom_action_complete:
                        getSupportActionBar().setTitle("Objetos Devolvidos");
                        getSupportFragmentManager().beginTransaction().setTransition( FragmentTransaction.TRANSIT_FRAGMENT_OPEN ).
                                replace(R.id.container, finishFragment).addToBackStack("Finalizado").commit();
                        return true;

                    case R.id.bottom_action_profile:
                        getSupportActionBar().setTitle("Perfil");
                        getSupportFragmentManager().beginTransaction().setTransition( FragmentTransaction.TRANSIT_FRAGMENT_OPEN ).
                                replace(R.id.container, profileFragment).addToBackStack("Perfil").commit();
                        return true;

                    default:
                        return false;
                }
            }
        });


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popAddPost.show();
            }
        });

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        updateNavHeader();

        getSupportFragmentManager().beginTransaction().replace(R.id.container, new HomeFragment()).commit();

    }

    private void setupPopupImageClick() {
        popupPostImag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Abrir a galeria e checar se tem acesso as fotos
                checkAndRequestForPermission();


            }
        });
    }

    private void checkAndRequestForPermission() {

        if (ContextCompat.checkSelfPermission(Home.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(Home.this, Manifest.permission.READ_EXTERNAL_STORAGE)) {

                StyleableToast.makeText(Home.this, "Por favor, aceite a permissão requerida.", Toast.LENGTH_LONG, R.style.advertenciaToast).show();

            } else {
                ActivityCompat.requestPermissions(Home.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE}, PReqCode);

            }

        } else
            // tudo ocorreu bem
            openImageIntent();
    }

    // Abre as opções de galeria e camera
    private void openImageIntent() {
        // TODO: abre a view galeria e espera o usuario escolher uma imagem !
        // TODO: abre a view camera e espera o usuario tirar uma foto

        File outputFile = null;
        try {
            outputFile = File.createTempFile("tmp", ".jpg", getCacheDir());
        } catch (IOException pE) {
            pE.printStackTrace();
        }
        pickedImgUri = Uri.fromFile(outputFile);


        // Camera.
        final List<Intent> cameraIntents = new ArrayList<Intent>();
        final Intent captureIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        final PackageManager packageManager = getPackageManager();
        final List<ResolveInfo> listCam = packageManager.queryIntentActivities(captureIntent, 0);
        for(ResolveInfo res : listCam) {
            final String packageName = res.activityInfo.packageName;
            final Intent intent = new Intent(captureIntent);
            intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
            intent.setPackage(packageName);
            cameraIntents.add(intent);
        }

        // Filesystem.
        final Intent galleryIntent = new Intent();
        galleryIntent.setType("image/*");
        galleryIntent.setAction(Intent.ACTION_PICK);

        // Chooser of filesystem options.
        final Intent chooserIntent = Intent.createChooser(galleryIntent, "Select Source");

        // Add the camera options.
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, cameraIntents.toArray(new Parcelable[cameraIntents.size()]));

        startActivityForResult(chooserIntent, REQUESCODE);
    }

    // Quando o usuario escolhe uma imagem ou tira uma foto
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUESCODE) {
                Bitmap bmp = null;
                if (data.hasExtra("data")) {
                    Bundle extras = data.getExtras();
                    bmp = (Bitmap) extras.get("data");
                } else {
                    AssetFileDescriptor fd = null;
                    try {
                        fd = getContentResolver().openAssetFileDescriptor(data.getData(), "r");
                    } catch (FileNotFoundException pE) {
                        pE.printStackTrace();
                    }
                    bmp = BitmapFactory.decodeFileDescriptor(fd.getFileDescriptor());
                }
                try {
                    FileOutputStream out = new FileOutputStream(new File(pickedImgUri.getPath()));
                    bmp.compress(Bitmap.CompressFormat.JPEG, 100, out);
                    out.flush();
                    out.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                popupPostImag.setImageURI(pickedImgUri);
                popupPostImag.setScaleType(ImageView.ScaleType.CENTER_CROP);

            }
        }
    }


    private void iniPopup() {

        popAddPost = new Dialog(this);
        popAddPost.setContentView(R.layout.popup_add_post);
        popAddPost.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popAddPost.getWindow().setLayout(Toolbar.LayoutParams.MATCH_PARENT, Toolbar.LayoutParams.WRAP_CONTENT);
        popAddPost.getWindow().getAttributes().gravity = Gravity.TOP;

        // ini popup widgets
        popupUserImage = popAddPost.findViewById(R.id.popup_user_image);
        popupPostImag = popAddPost.findViewById(R.id.popup_img);
        popupTitle = popAddPost.findViewById(R.id.popup_title);
        popupContact = popAddPost.findViewById(R.id.popup_contact);
        popupDescription = popAddPost.findViewById(R.id.popup_description);
        popupSpinner = popAddPost.findViewById(R.id.my_spinner);
        popupAddBtn = popAddPost.findViewById(R.id.popup_add);
        popupClickProgress = popAddPost.findViewById(R.id.popup_progressBar);

        // Pega a imagem de usuario e coloca no add post
        Glide.with(Home.this).load(currentUser.getPhotoUrl()).into(popupUserImage);

        // Coloca uma imagem padrão no popupPostImag
        //popupPostImag.setImageDrawable(getResources().getDrawable(R.drawable.add_image));

        popupContact.addTextChangedListener(MaskEditUtil.mask((EditText) popupContact, "(##) #####-####"));

        // Mostra opções no edittext de procurar (Api Google Maps)
        popupSearchMap = popAddPost.findViewById(R.id.popup_search_map);


        // Add post click Listener
        popupAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupAddBtn.setVisibility(View.INVISIBLE);
                popupClickProgress.setVisibility(View.VISIBLE);

                // testar os campos
                if (!popupTitle.getText().toString().isEmpty() && !popupDescription.getText().toString().isEmpty() && !popupContact.getText().toString().isEmpty() && pickedImgUri!= null){
                    // todos os campos estão preenchidos
                    // TODO: Criação do Objeto Post e Adiciona no Firebase Database
                    StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("blog_images");

                    final StorageReference imageFilePath = storageReference.child(pickedImgUri.getLastPathSegment());

                    imageFilePath.putFile(pickedImgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            imageFilePath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    String imageDownloadLink = uri.toString();
                                    // Criação do post Object
                                    Post post = new Post(currentUser.getDisplayName(), popupTitle.getText().toString(), popupDescription.getText().toString(), popupSpinner.getSelectedItem().toString(), popupContact.getText().toString(), currentUser.getEmail(), imageDownloadLink,
                                            currentUser.getUid(), currentUser.getPhotoUrl().toString());

                                    // adiciona o post ao firebase database

                                    addPost(post);
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    // alguma falha com o upload da imagem aconteceu
                                    StyleableToast.makeText(Home.this, e.getMessage(), Toast.LENGTH_LONG, R.style.erroToast).show();
                                    popupClickProgress.setVisibility(View.INVISIBLE);
                                    popupAddBtn.setVisibility(View.VISIBLE);
                                }
                            });
                        }
                    });


                } else {
                    StyleableToast.makeText(Home.this, "Preenche os campos e adicione uma imagem!!", Toast.LENGTH_LONG, R.style.advertenciaToast).show();
                    popupAddBtn.setVisibility(View.VISIBLE);
                    popupClickProgress.setVisibility(View.INVISIBLE);
                }

            }
        });
    }

    private void addPost(Post post) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Posts").push();

        // pega o ID unico do post e  atualiza a chave(key) do post
        String key = myRef.getKey();
        post.setPostKey(key);

        // adiciona o conteudo do post no firebase database e remove os dados no popup
        myRef.setValue(post).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                StyleableToast.makeText(Home.this, "Item adicionado com Sucesso!", Toast.LENGTH_LONG, R.style.sucessoToast).show();
                popupAddBtn.setVisibility(View.VISIBLE);
                popupClickProgress.setVisibility(View.INVISIBLE);
                popupDescription.setText("");
                popupTitle.setText("");
                popupContact.setText("");
                Drawable drawable = ContextCompat.getDrawable(Home.this, R.drawable.ic_image_add);
                popupPostImag.setImageDrawable(drawable);
                popupPostImag.setScaleType(ImageView.ScaleType.FIT_CENTER);

                //popupPostImag.setImageDrawable(getResources().getDrawable(R.drawable.ic_image_add));

                //popupPostImag.setImageURI(null);
                popAddPost.dismiss();
            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {

            getSupportActionBar().setTitle("Início");
            mainBottomNav.setSelectedItemId(R.id.bottom_action_home);
            getSupportFragmentManager().beginTransaction().setTransition( FragmentTransaction.TRANSIT_FRAGMENT_OPEN ).
                    replace(R.id.container, homeFragment).addToBackStack("Home").commit();

        } else if (id == R.id.nav_profile) {

            getSupportActionBar().setTitle("Perfil");
            mainBottomNav.setSelectedItemId(R.id.bottom_action_profile);
            getSupportFragmentManager().beginTransaction().setTransition( FragmentTransaction.TRANSIT_FRAGMENT_OPEN ).
                    replace(R.id.container, profileFragment).addToBackStack("Perfil").commit();

        } else if (id == R.id.nav_settings) {

            //getSupportActionBar().setTitle("Configuração");
            Intent settingsActivity = new Intent(this, SettingsActivity.class);
            startActivity(settingsActivity);
            finish();

        } else if (id == R.id.nav_about) {

            //getSupportActionBar().setTitle("Sobre");
            Intent aboutActivity = new Intent(this, AboutActivity.class);
            startActivity(aboutActivity);
            finish();
            //getSupportFragmentManager().beginTransaction().replace(R.id.container, new AboutFragment()).commit();
            //getSupportFragmentManager().beginTransaction().replace(R.id.container, new AboutFragment()).commit();

        } else if (id == R.id.nav_signout){

            FirebaseAuth.getInstance().signOut();
            Intent loginActivity = new Intent(this, LoginActivity.class);
            startActivity(loginActivity);
            finish();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void updateNavHeader(){
        NavigationView navigationView = findViewById(R.id.nav_view);
        View headerView = navigationView.getHeaderView(0);
        TextView navUsername = headerView.findViewById(R.id.nav_username);
        TextView navUserMail = headerView.findViewById(R.id.nav_user_mail);
        CircleImageView navUserPhot = headerView.findViewById(R.id.nav_user_photo);

        navUserMail.setText(currentUser.getEmail());
        navUsername.setText(currentUser.getDisplayName());
        navUserPhot.setImageURI(currentUser.getPhotoUrl());

        // Utilizando Glide para carregar a imagem
        // Importado no gradle

        Glide.with(this).load(currentUser.getPhotoUrl()).into(navUserPhot);
    }

    private void replaceFragment(Fragment fragment){

        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.container, fragment);
        fragmentTransaction.commit();
    }
}
