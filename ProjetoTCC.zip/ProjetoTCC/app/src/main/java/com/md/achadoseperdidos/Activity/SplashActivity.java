package com.md.achadoseperdidos.Activity;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.crashlytics.android.Crashlytics;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.md.achadoseperdidos.R;
import com.md.achadoseperdidos.databinding.ActivitySplashBinding;
import io.fabric.sdk.android.Fabric;

public class SplashActivity extends AppCompatActivity {
    ActivitySplashBinding binding;

    private FirebaseAuth mAuth;
    private Intent HomeActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fabric.with(this, new Crashlytics());
        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash);

        // Firebase
        mAuth = FirebaseAuth.getInstance();

        HomeActivity = new Intent(this, com.md.achadoseperdidos.Activity.Home.class);
    }

    private void updateUI() {
        startActivity(HomeActivity);
        finish();
    }

    public void  login(View view)
    {
        startActivity(new Intent(this,LoginActivity.class));
    }


    public void  getStarted(View view)
    {
        startActivity(new Intent(this, RegisterActivity.class));
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser user = mAuth.getCurrentUser();

        if(user != null) {
            //usuario já está conectado, assim redireciona ele para a tela home
            updateUI();

        }
    }

}
