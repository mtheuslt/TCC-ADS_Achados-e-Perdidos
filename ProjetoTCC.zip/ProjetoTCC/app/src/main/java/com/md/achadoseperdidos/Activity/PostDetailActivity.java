package com.md.achadoseperdidos.Activity;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.md.achadoseperdidos.R;

import java.util.Calendar;
import java.util.Locale;

public class PostDetailActivity extends AppCompatActivity {

    ImageView imgPost, imgUserPost;
    TextView txtPostDesc, txtPostDateName, txtPostTitle, txtPostContact, txtPostEmail;
    ImageView btnPostCelphone, btnPostEmail;
    String PostKey;

    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_detail);

        if(getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();

        // ini Views
        imgPost = findViewById(R.id.post_detail_img);
        imgUserPost = findViewById(R.id.post_detail_user_img);

        txtPostTitle = findViewById(R.id.post_detail_title);
        txtPostDesc = findViewById(R.id.post_detail_desc);
        txtPostDateName = findViewById(R.id.post_detail_date);
        txtPostContact = findViewById(R.id.post_detail_contact);
        txtPostEmail = findViewById(R.id.post_detail_email);
        btnPostCelphone = findViewById(R.id.post_button_celphone);
        btnPostEmail = findViewById(R.id.post_button_email);

        // colocar todas as informações com o padrão do PostAdapter

        String postImage = getIntent().getExtras().getString("postImage");
        Glide.with(this).load(postImage).into(imgPost);

        String postTitle = getIntent().getExtras().getString("title");
        txtPostTitle.setText(postTitle);

        String postDescription = getIntent().getExtras().getString("description");
        txtPostDesc.setText(postDescription);

        final String postContact = getIntent().getExtras().getString("contact");
        txtPostContact.setText(postContact);

        final String postEmail = getIntent().getExtras().getString("email");
        txtPostEmail.setText(postEmail);

        // mandar email

        btnPostEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", postEmail, null));
                startActivity(new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", postEmail, null)));
            }
        });

        // Ligar para o número

        btnPostCelphone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", postContact, null)));
            }
        });

        String userpostImage = getIntent().getExtras().getString("userPhoto");
        Glide.with(this).load(userpostImage).into(imgUserPost);

        // post id
        PostKey = getIntent().getExtras().getString("postKey");

        String date = timestampToString(getIntent().getExtras().getLong("postDate"));
        txtPostDateName.setText(date);

    }

    private String timestampToString(long time) {

        Calendar calendar = Calendar.getInstance(Locale.getDefault());
        calendar.setTimeInMillis(time);
        String postName = getIntent().getExtras().getString("userName");
        String dateFormat = DateFormat.format("dd MMMM yyyy, hh:mm:ss", calendar).toString();
        String date = dateFormat +  " | por " + postName;
        return date;
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
