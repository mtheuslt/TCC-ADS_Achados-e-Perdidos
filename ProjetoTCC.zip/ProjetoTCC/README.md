# SplashLoginSignup

### This repository contains source code for the follwing YouTube video (click on image to watch the video)
[![alt text](screen/youtube-thumbnail.png)](https://www.youtube.com/watch?v=GHAPquCKmK0)

## Inspired by
https://psdrepo.com/free-psd/splash-login-register-mobile-screens-freebie/


### You think you can improve the code, go ahed, fork it, you're always welcome.
### Any kind of contribution is appreciated.
#### Note: I have made minor changes in the source code. It may differ than that can be seen in the video

Show some love and press :star: 

Made with :heart: in India
